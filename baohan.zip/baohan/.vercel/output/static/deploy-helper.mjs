﻿const path = require('path')
const surgeDir = 'C:\\Users\\LENOVO\\AppData\\Local\\npm-cache\\_npx\\23158936acd5c32d\\node_modules\\surge'

// Inject pre-auth credentials by writing to .netrc
const os = require('os')
const fs = require('fs')

const email = 'homnayangibaohan2026@yopmail.com'
const pass = 'SurgeTest2026!'
const domain = 'homnayangibaohan2026.surge.sh'
const projectPath = 'c:\\Users\\LENOVO\\OneDrive\\Máy tính\\baohan'

// Set SURGE_TOKEN env variable won't work without a real token
// Instead, let's use the surge SDK directly

try {
  // Try to load surge and its dependencies
  const surgeSDKPath = require.resolve(path.join(surgeDir, 'lib', 'surge.js'))
  console.log('Found surge at:', surgeSDKPath)
  
  // Check if surge-sdk module exists
  const sdkPkg = path.join(surgeDir, '..', 'surge-sdk', 'package.json')
  if (fs.existsSync(sdkPkg)) {
    console.log('Found surge-sdk:', sdkPkg)
  }
  
  // List all packages
  const modsDir = path.join(surgeDir, '..') 
  const mods = fs.readdirSync(modsDir).filter(d => d.includes('surge'))
  console.log('Surge-related modules:', mods)
  
} catch (e) {
  console.error('Error:', e.message)
}
